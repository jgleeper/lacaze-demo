(() => {
  const btn = document.querySelector('.navtoggle');
  const mobile = document.getElementById('mobileNav');

  if (!btn || !mobile) return;

  const close = () => {
    btn.setAttribute('aria-expanded', 'false');
    mobile.hidden = true;
  };

  const open = () => {
    btn.setAttribute('aria-expanded', 'true');
    mobile.hidden = false;
  };

  btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    expanded ? close() : open();
  });

  // Close mobile nav after clicking a link
  mobile.addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (!a) return;
    close();
  });

  // Close on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });
})();
